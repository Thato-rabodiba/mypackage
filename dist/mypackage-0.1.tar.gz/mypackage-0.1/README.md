# mypackage

Steps on understanding how to create your own python package from scratch.